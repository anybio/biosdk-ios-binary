//
//  ABSchemaBasedProfile.h
//  BioBLECore
//
//  Schema-based device profile implementation
//  Dynamically interprets JSON schemas to decode BLE packets
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#if __has_include(<BioSDK/ABDeviceProfile.h>)
#import <BioSDK/ABDeviceProfile.h>
#else
#import "ABDeviceProfile.h"
#endif

NS_ASSUME_NONNULL_BEGIN

/**
 * Generic device profile implementation that interprets JSON schemas.
 *
 * This class eliminates the need for hardcoded device-specific profiles.
 * Instead, it loads schema definitions (services, decoders, transforms)
 * and dynamically parses BLE packets according to the schema rules.
 *
 * Key features:
 * - Multi-mode packet detection (different formats per mode)
 * - Transform compilation and caching (linear, polynomial, etc.)
 * - Schema-based field decoding (i16_le_array, u8, etc.)
 * - Custom decoder dispatch for vendor-specific protocols
 *
 * Example schema structure:
 * {
 *   "name": "Senstream Ring",
 *   "services": [{"uuid": "...", "characteristics": [...]}],
 *   "decoder": {
 *     "type": "multi_mode",
 *     "modes": {
 *       "research": {"packet_length": 244, "fields": [...]}
 *     }
 *   },
 *   "transforms": {
 *     "ecg_to_mv": {"type": "linear", "scale": 0.0244140625, "offset": 0}
 *   }
 * }
 */
@interface ABSchemaBasedProfile : NSObject <ABDeviceProfile>

/**
 * Initialize with a schema dictionary loaded from JSON.
 *
 * @param schema NSDictionary containing the schema definition
 * @return Initialized profile instance, or nil if schema is invalid
 */
- (nullable instancetype)initWithSchema:(NSDictionary *)schema;

/**
 * Initialize with a schema loaded from a bundle resource.
 *
 * @param resourceName Name of the JSON file (without extension)
 * @param bundle Bundle containing the resource, or nil for main bundle
 * @return Initialized profile instance, or nil if resource not found
 */
- (nullable instancetype)initWithSchemaResource:(NSString *)resourceName
                                         bundle:(nullable NSBundle *)bundle;

/**
 * The raw schema dictionary.
 */
@property (nonatomic, strong, readonly) NSDictionary *schema;

/**
 * Get the current mode (e.g., "research", "ecg", "scoring").
 * Used for multi-mode decoders.
 * Setting this property resets the synthetic timestamp anchor if timestamps are synthetic.
 */
@property (nonatomic, copy, nullable) NSString *currentMode;

/**
 * Reset the synthetic timestamp anchor.
 * Call this on session restart or device reconnect to re-establish the time base.
 * Only relevant for profiles with "timestamp_strategy": "synthetic_from_seq".
 */
- (void)resetSyntheticTimestampAnchor;

/**
 * Resolve a mode_id by length-sniffing a BLE notification's payload size
 * (device-profile-decoder-v2 §3.3 "Source of truth — length-discriminated
 * devices"). The SDK side uses this for Wellue-style devices that interleave
 * different packet types on the same characteristic with no control-point
 * mode-change write between them.
 *
 * Returns boxed NSNumber<uint32_t> when a mode matches; nil when no decoder
 * is registered for the characteristic OR no mode matches the length. The
 * nullable signature is load-bearing: spec §4.4 Wellue declares mode_id 0
 * for `ppg_waveform`, so a raw `uint32_t` return cannot distinguish "no
 * match" from "real mode_id 0". The Swift caller (RawPacketStreamer) uses
 * the optional to fall back to `activeModeIds` only when this returns nil.
 *
 * Matching policy (consistent with the §6 length-walk):
 *   1. Exact match on a fixed length wins.
 *   2. Otherwise the largest fixed length that fits wins.
 *   3. Otherwise a "variable"-length mode is used as a last-resort fallback.
 */
- (nullable NSNumber *)modeIdForCharacteristicUUID:(CBUUID *)characteristicUUID
                                notificationLength:(NSUInteger)length;

/**
 * YES only when this characteristic's decoder declares an explicit `modes`
 * dict (multi-mode / control-point-driven characteristic).
 *
 * NOT derivable from modeIdForCharacteristicUUID:notificationLength: —
 * single-mode characteristics get a synthesized "sugar" descriptor
 * {mode_id: 0} at profile load, so that method returns non-nil for them
 * too. The Swift caller (RawPacketStreamer) uses this to gate whether the
 * device-wide control-point active mode may be applied to a packet:
 * applying it to a single-mode characteristic (e.g. a ring's independent
 * accelerometer) tags packets with a mode the characteristic doesn't
 * declare, and the BE decoder silently drops the whole batch. Client twin
 * of the BE's characteristic_has_modes.
 */
- (BOOL)characteristicHasModes:(CBUUID *)characteristicUUID;

/**
 * YES when this characteristic's decoder carries the v2 §3.3
 * `length_discriminated` contract flag: its modes are resolved PER PACKET by
 * notification length (Wellue-style interleaving on one characteristic).
 * The Swift caller (RawPacketStreamer) uses this to keep the device-wide
 * control-point active mode from pinning such a characteristic's packets to
 * one mode — that would mis-tag every interleaved other-mode packet.
 */
- (BOOL)characteristicIsLengthDiscriminated:(CBUUID *)characteristicUUID;

/**
 * Resolve the profile-declared mode_id matching the current `currentMode`
 * string (control-point dispatch case, e.g. Senstream legacy/scoring).
 * Returns 0 if `currentMode` is nil or doesn't match any declared mode.
 */
- (uint32_t)modeIdForCurrentModeName;

@end

NS_ASSUME_NONNULL_END
