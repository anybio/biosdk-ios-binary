//
//  ABBioTypes.h
//  BioBLECore
//
//  Core types and enumerations for BioSDK
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

// MARK: - Connection States

/// BLE connection state for a device
typedef NS_ENUM(NSInteger, ABBioConnectionState) {
    ABBioConnectionStateDiscovered,
    ABBioConnectionStateConnecting,
    ABBioConnectionStateDiscoveringServices,
    ABBioConnectionStateReady,
    ABBioConnectionStateFailed,
    ABBioConnectionStateDisconnected
};

/// Streaming state for a device
typedef NS_ENUM(NSInteger, ABBioStreamState) {
    ABBioStreamStateIdle,
    ABBioStreamStateStarting,
    ABBioStreamStateStreaming,
    ABBioStreamStateStopping,
    ABBioStreamStateStalled,
    ABBioStreamStateUnsupported
};

// MARK: - Device Types

/// Device form factor classification
typedef NS_ENUM(NSInteger, ABBioDeviceType) {
    ABBioDeviceTypeRing,
    ABBioDeviceTypeHRM,
    ABBioDeviceTypeUnknown
};

/// Biosignal types supported by devices
typedef NS_ENUM(NSInteger, ABBiosignalType) {
    ABBiosignalTypeECG,
    ABBiosignalTypePPG,
    ABBiosignalTypeEDA,
    ABBiosignalTypeTemp,
    ABBiosignalTypeHeartRate,
    ABBiosignalTypeSPO2,
    ABBiosignalTypeHRV,
    ABBiosignalTypeAccelerometer,
    ABBiosignalTypeGyroscope,
    ABBiosignalTypeAccelX,
    ABBiosignalTypeAccelY,
    ABBiosignalTypeAccelZ,
    ABBiosignalTypeGyroX,
    ABBiosignalTypeGyroY,
    ABBiosignalTypeGyroZ,
    ABBiosignalTypeBattery,
    ABBiosignalTypeUnknown
};

// MARK: - Sample Types

/// Sample data type (waveform vs scalar)
typedef NS_ENUM(NSInteger, ABBioSampleType) {
    ABBioSampleTypeWaveform,  ///< Time-series array (e.g., ECG, PPG)
    ABBioSampleTypeScalar     ///< Single value (e.g., heart rate, temperature)
};

// MARK: - Helper Functions

/// Convert connection state to string
NSString* ABBioConnectionStateToString(ABBioConnectionState state);

/// Convert stream state to string
NSString* ABBioStreamStateToString(ABBioStreamState state);

/// Convert biosignal type to string
NSString* ABBiosignalTypeToString(ABBiosignalType type);

NS_ASSUME_NONNULL_END
