//
//  ABSchemaBasedProfile.h
//  BioBLECore
//
//  Schema-based device profile implementation
//  Dynamically interprets JSON schemas to decode BLE packets
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#if __has_include(<BioSDK/ABDeviceProfile.h>)
#import <BioSDK/ABDeviceProfile.h>
#else
#import "ABDeviceProfile.h"
#endif

NS_ASSUME_NONNULL_BEGIN

/**
 * Generic device profile implementation that interprets JSON schemas.
 *
 * This class eliminates the need for hardcoded device-specific profiles.
 * Instead, it loads schema definitions (services, decoders, transforms)
 * and dynamically parses BLE packets according to the schema rules.
 *
 * Key features:
 * - Multi-mode packet detection (different formats per mode)
 * - Transform compilation and caching (linear, polynomial, etc.)
 * - Schema-based field decoding (i16_le_array, u8, etc.)
 * - Custom decoder dispatch for vendor-specific protocols
 *
 * Example schema structure:
 * {
 *   "name": "Senstream Ring",
 *   "services": [{"uuid": "...", "characteristics": [...]}],
 *   "decoder": {
 *     "type": "multi_mode",
 *     "modes": {
 *       "research": {"packet_length": 244, "fields": [...]}
 *     }
 *   },
 *   "transforms": {
 *     "ecg_to_mv": {"type": "linear", "scale": 0.0244140625, "offset": 0}
 *   }
 * }
 */
@interface ABSchemaBasedProfile : NSObject <ABDeviceProfile>

/**
 * Initialize with a schema dictionary loaded from JSON.
 *
 * @param schema NSDictionary containing the schema definition
 * @return Initialized profile instance, or nil if schema is invalid
 */
- (nullable instancetype)initWithSchema:(NSDictionary *)schema;

/**
 * Initialize with a schema loaded from a bundle resource.
 *
 * @param resourceName Name of the JSON file (without extension)
 * @param bundle Bundle containing the resource, or nil for main bundle
 * @return Initialized profile instance, or nil if resource not found
 */
- (nullable instancetype)initWithSchemaResource:(NSString *)resourceName
                                         bundle:(nullable NSBundle *)bundle;

/**
 * The raw schema dictionary.
 */
@property (nonatomic, strong, readonly) NSDictionary *schema;

/**
 * Get the current mode (e.g., "research", "ecg", "scoring").
 * Used for multi-mode decoders.
 */
@property (nonatomic, copy, nullable) NSString *currentMode;

@end

NS_ASSUME_NONNULL_END
