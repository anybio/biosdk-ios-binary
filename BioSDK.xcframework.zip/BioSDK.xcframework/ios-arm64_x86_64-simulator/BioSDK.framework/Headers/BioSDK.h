//
//  BioSDK.h
//  BioSDK
//
//  Unified BioSDK Framework
//  Combines BioSDKCore, BioBLECore, BioBLE, BioIngest, and BioSDK modules
//

#ifndef BioSDK_h
#define BioSDK_h

#import <Foundation/Foundation.h>

//! Project version number for BioSDK.
FOUNDATION_EXPORT double BioSDKVersionNumber;

//! Project version string for BioSDK.
FOUNDATION_EXPORT const unsigned char BioSDKVersionString[];

// BioBLECore Public Headers
#import <BioSDK/ABBioTypes.h>
#import <BioSDK/ABBioEvent.h>
#import <BioSDK/ABBioSample.h>
#import <BioSDK/ABBioDevice.h>
#import <BioSDK/ABDeviceProfile.h>
#import <BioSDK/ABSchemaBasedProfile.h>
#import <BioSDK/ABProfileRegistry.h>
#import <BioSDK/ABBioBLEManager.h>

#endif /* BioSDK_h */
