//
//  ABDeviceProfile.h
//  BioBLECore
//
//  Device profile protocol for GATT service parsing
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#if __has_include(<BioSDK/ABBioTypes.h>)
#import <BioSDK/ABBioTypes.h>
#else
#import "ABBioTypes.h"
#endif

@class ABBioSample;

NS_ASSUME_NONNULL_BEGIN

/// Device profile protocol for parsing BLE GATT services
@protocol ABDeviceProfile <NSObject>

/// Profile name (e.g., "Senstream", "HRM")
@property (nonatomic, copy, readonly) NSString *name;

/// Service UUIDs this profile handles
@property (nonatomic, copy, readonly) NSArray<CBUUID *> *serviceUUIDs;

/// Characteristic UUIDs this profile subscribes to
@property (nonatomic, copy, readonly) NSArray<CBUUID *> *characteristicUUIDs;

/// Biosignal capabilities provided by this profile
@property (nonatomic, copy, readonly) NSArray<NSNumber *> *capabilities; // Array of ABBiosignalType

/// Decode raw BLE data into biosignal samples
/// @param data Raw BLE characteristic data
/// @param characteristicUUID The characteristic UUID
/// @param deviceId Device identifier
/// @return Array of decoded BioSamples (may be multiple samples per packet)
- (NSArray<ABBioSample *> *)decodeSamples:(NSData *)data
                       characteristicUUID:(CBUUID *)characteristicUUID
                                 deviceId:(NSString *)deviceId;

@optional

/// Check if this profile matches a peripheral based on advertisement
/// @param peripheral The BLE peripheral
/// @param advertisementData Advertisement data
/// @return YES if this profile can handle this device
- (BOOL)matchesPeripheral:(CBPeripheral *)peripheral
       advertisementData:(NSDictionary<NSString *, id> *)advertisementData;

/// Optional setup after service discovery (e.g., write control characteristics)
/// @param peripheral The connected peripheral
- (void)setupDevice:(CBPeripheral *)peripheral;

@end

NS_ASSUME_NONNULL_END
