//
//  ABBioDevice.h
//  BioBLECore
//
//  BLE device model
//

#import <Foundation/Foundation.h>
#if __has_include(<BioSDK/ABBioTypes.h>)
#import <BioSDK/ABBioTypes.h>
#else
#import "ABBioTypes.h"
#endif

NS_ASSUME_NONNULL_BEGIN

/// BLE Device representation
@interface ABBioDevice : NSObject

/// Device unique identifier (UUID string)
@property (nonatomic, copy, readonly) NSString *deviceId;

/// Device name (from BLE advertisement)
@property (nonatomic, copy, readonly) NSString *name;

/// Device type (ring, HRM, unknown)
@property (nonatomic, assign, readonly) ABBioDeviceType deviceType;

/// Current connection state
@property (nonatomic, assign, readonly) ABBioConnectionState connectionState;

/// Current stream state
@property (nonatomic, assign, readonly) ABBioStreamState streamState;

/// Manufacturer name (from Device Information Service)
@property (nonatomic, copy, readonly, nullable) NSString *make;

/// Model number (from Device Information Service)
@property (nonatomic, copy, readonly, nullable) NSString *model;

/// Firmware version (from Device Information Service)
@property (nonatomic, copy, readonly, nullable) NSString *firmware;

/// Battery level (0-100, nil if unavailable)
@property (nonatomic, strong, readonly, nullable) NSNumber *battery;

/// RSSI (signal strength)
@property (nonatomic, strong, readonly, nullable) NSNumber *rssi;

/// Supported biosignal types
@property (nonatomic, copy, readonly) NSArray<NSNumber *> *capabilities; // Array of ABBiosignalType

// MARK: - Initializers

- (instancetype)initWithDeviceId:(NSString *)deviceId
                            name:(NSString *)name
                      deviceType:(ABBioDeviceType)deviceType
                 connectionState:(ABBioConnectionState)connectionState
                     streamState:(ABBioStreamState)streamState
                    capabilities:(NSArray<NSNumber *> *)capabilities;

/// Check if device has a specific capability
- (BOOL)hasCapability:(ABBiosignalType)biosignalType;

@end

NS_ASSUME_NONNULL_END
