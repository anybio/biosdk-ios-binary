//
//  ABBioSample.h
//  BioBLECore
//
//  Biosignal sample data model
//

#import <Foundation/Foundation.h>
#if __has_include(<BioSDK/ABBioTypes.h>)
#import <BioSDK/ABBioTypes.h>
#else
#import "ABBioTypes.h"
#endif

NS_ASSUME_NONNULL_BEGIN

/// Biosignal sample data
@interface ABBioSample : NSObject

/// Signal name (e.g., "ecg", "ppg", "heart_rate")
@property (nonatomic, copy, readonly) NSString *signalName;

/// Biosignal type
@property (nonatomic, assign, readonly) ABBiosignalType biosignalType;

/// Sample type (waveform or scalar)
@property (nonatomic, assign, readonly) ABBioSampleType sampleType;

/// Timestamp when the sample was captured
@property (nonatomic, strong, readonly) NSDate *timestamp;

/// Waveform data (array of Double values) - nil if scalar sample
@property (nonatomic, copy, readonly, nullable) NSArray<NSNumber *> *waveform;

/// Scalar value - nil if waveform sample
@property (nonatomic, strong, readonly, nullable) NSNumber *scalarValue;

/// Device ID that generated this sample
@property (nonatomic, copy, readonly) NSString *deviceId;

/// Sample rate in Hz (for waveforms)
@property (nonatomic, assign, readonly) double sampleRate;

// MARK: - Initializers

/// Create a waveform sample
+ (instancetype)waveformSampleWithSignalName:(NSString *)signalName
                               biosignalType:(ABBiosignalType)biosignalType
                                   timestamp:(NSDate *)timestamp
                                    waveform:(NSArray<NSNumber *> *)waveform
                                    deviceId:(NSString *)deviceId
                                  sampleRate:(double)sampleRate;

/// Create a scalar sample
+ (instancetype)scalarSampleWithSignalName:(NSString *)signalName
                             biosignalType:(ABBiosignalType)biosignalType
                                 timestamp:(NSDate *)timestamp
                               scalarValue:(double)scalarValue
                                  deviceId:(NSString *)deviceId;

@end

NS_ASSUME_NONNULL_END
