//
//  ABBioBLEManager.h
//  BioBLECore
//
//  Main BLE manager for device discovery, connection, and streaming
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#if __has_include(<BioSDK/ABBioTypes.h>)
#import <BioSDK/ABBioTypes.h>
#else
#import "ABBioTypes.h"
#endif

@class ABBioEvent;
@class ABBioDevice;
@protocol ABDeviceProfile;

NS_ASSUME_NONNULL_BEGIN

// MARK: - Delegate Protocol

/// Delegate protocol for BLE manager events
@protocol ABBioBLEManagerDelegate <NSObject>

/// Called when a new event occurs (sample, connection, error, etc.)
/// @param event The event that occurred
- (void)bioBLEManager:(id)manager didReceiveEvent:(ABBioEvent *)event;

@optional

/// Called when the discovered devices list changes
/// @param devices Array of discovered devices
- (void)bioBLEManager:(id)manager didUpdateDiscoveredDevices:(NSArray<ABBioDevice *> *)devices;

@end

// MARK: - ABBioBLEManager

/// Main BLE manager for biosignal device connectivity
@interface ABBioBLEManager : NSObject

/// Shared singleton instance
@property (class, nonatomic, readonly) ABBioBLEManager *sharedManager;

/// Delegate for receiving events
@property (nonatomic, weak, nullable) id<ABBioBLEManagerDelegate> delegate;

/// List of discovered devices
@property (nonatomic, copy, readonly) NSArray<ABBioDevice *> *discoveredDevices;

/// Current Bluetooth state
@property (nonatomic, assign, readonly) CBManagerState bluetoothState;

// MARK: - Device Scanning

/// Start scanning for BLE devices
- (void)startScan;

/// Stop scanning for BLE devices
- (void)stopScan;

/// Check if currently scanning
@property (nonatomic, assign, readonly, getter=isScanning) BOOL scanning;

// MARK: - Device Connection

/// Connect to a device
/// @param deviceId Device UUID string
- (void)connectToDevice:(NSString *)deviceId;

/// Disconnect from a device
/// @param deviceId Device UUID string
- (void)disconnectFromDevice:(NSString *)deviceId;

/// Get device by ID
/// @param deviceId Device UUID string
/// @return Device if found, nil otherwise
- (nullable ABBioDevice *)deviceWithId:(NSString *)deviceId;

/// Get the profile for a connected device
/// @param deviceId Device UUID string
/// @return Device profile if found, nil otherwise
- (nullable id<ABDeviceProfile>)profileForDevice:(NSString *)deviceId;

// MARK: - Streaming Control

/// Start streaming data from a device
/// @param deviceId Device UUID string
- (void)startStreaming:(NSString *)deviceId;

/// Stop streaming data from a device
/// @param deviceId Device UUID string
- (void)stopStreaming:(NSString *)deviceId;

/// Set auto-stream flag for a device (stream automatically after connection)
/// @param enabled Whether to auto-stream
/// @param deviceId Device UUID string
- (void)setAutoStream:(BOOL)enabled forDevice:(NSString *)deviceId;

/// Check if auto-stream is enabled for a device
/// @param deviceId Device UUID string
/// @return YES if auto-stream is enabled, NO otherwise
- (BOOL)autoStreamEnabledForDevice:(NSString *)deviceId;

// MARK: - Device Operations

/// Execute a device operation (write to characteristic)
/// @param deviceId Device UUID string
/// @param operationName Name of the operation to execute
/// @param completionHandler Called when operation completes or fails
- (void)executeOperation:(NSString *)operationName
               forDevice:(NSString *)deviceId
       completionHandler:(void (^)(NSError * _Nullable error))completionHandler;

// MARK: - Streaming Profiles

/// Activate a streaming profile for a device.
/// Executes the profile's operations in order, then sets auto-reconnect.
/// On reconnect, the same operations are replayed automatically.
/// @param profileName Name of the streaming profile (from schema streaming_profiles)
/// @param deviceId Device UUID string
/// @param completionHandler Called when all operations complete or any fails
- (void)activateStreamingProfile:(NSString *)profileName
                       forDevice:(NSString *)deviceId
               completionHandler:(void (^)(NSError * _Nullable error))completionHandler;

/// Deactivate the active streaming profile for a device.
/// Clears auto-reconnect and optionally executes StopStreaming operation.
/// @param deviceId Device UUID string
/// @param executeStop Whether to execute StopStreaming operation (if available)
- (void)deactivateStreamingProfile:(NSString *)deviceId executeStop:(BOOL)executeStop;

/// Get the active streaming profile name for a device
/// @param deviceId Device UUID string
/// @return Profile name or nil if no profile is active
- (nullable NSString *)activeStreamingProfileForDevice:(NSString *)deviceId;

/// Seed a streaming profile entry for a device without executing operations.
/// Used during app restoration to pre-populate the replay dictionary before device reconnects.
/// @param profileName Name of the streaming profile
/// @param deviceId Device UUID string
- (void)seedStreamingProfile:(NSString *)profileName forDevice:(NSString *)deviceId;

/// Clear all persisted BLE reconnection state (autoStreamFlags + activeStreamingProfiles).
/// Call when ending a session to ensure no stale reconnection state survives.
- (void)clearPersistedBLEState;

/// Attempt to reconnect to devices by UUID using CoreBluetooth's retrievePeripherals API.
/// Works without scanning — retrieves CBPeripheral objects by UUID and calls connectPeripheral.
/// Used after force-kill to reconnect to session devices whose UUIDs are persisted.
/// @param deviceIds Array of device UUID strings to reconnect
- (void)reconnectSessionDevices:(NSArray<NSString *> *)deviceIds;

// MARK: - Device Profile Management

/// Register a custom device profile
/// @param profile Device profile conforming to ABDeviceProfile protocol
- (void)registerDeviceProfile:(id<ABDeviceProfile>)profile;

/// Unregister a device profile
/// @param profileName Name of the profile to unregister
- (void)unregisterDeviceProfile:(NSString *)profileName;

/// Get registered profiles
@property (nonatomic, copy, readonly) NSArray<id<ABDeviceProfile>> *registeredProfiles;

/// Re-match connected peripherals against registered profiles
/// Call this after registering new profiles to handle peripherals restored during app launch
- (void)rematchConnectedPeripherals;

// MARK: - Raw Packet Callback

/// Optional callback for raw BLE packets (for zero-data-loss architectures)
/// Called before decoding with (deviceId, characteristicUUID, data, timestamp)
@property (nonatomic, copy, nullable) void (^onRawPacket)(NSString *deviceId, NSString *characteristicUUID, NSData *data, NSDate *timestamp);

// MARK: - RSSI Monitoring

/// Optional callback for RSSI updates during active sessions
/// Called periodically with (deviceId, rssi) for each connected+streaming peripheral
@property (nonatomic, copy, nullable) void (^onRSSIUpdate)(NSString *deviceId, NSNumber *rssi);

/// Start periodic RSSI polling for all connected+streaming peripherals (30s interval)
- (void)startRSSIPolling;

/// Stop RSSI polling
- (void)stopRSSIPolling;

/// Whether RSSI polling is currently active
@property (nonatomic, assign, readonly, getter=isRSSIPollingActive) BOOL rssiPollingActive;

@end

NS_ASSUME_NONNULL_END
