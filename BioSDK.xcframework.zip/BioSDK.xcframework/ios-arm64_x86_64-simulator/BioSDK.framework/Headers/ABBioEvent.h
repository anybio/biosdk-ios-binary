//
//  ABBioEvent.h
//  BioBLECore
//
//  Event system for BLE lifecycle, samples, and state changes
//

#import <Foundation/Foundation.h>
#if __has_include(<BioSDK/ABBioTypes.h>)
#import <BioSDK/ABBioTypes.h>
#else
#import "ABBioTypes.h"
#endif

@class ABBioSample;
@class ABBioDevice;

NS_ASSUME_NONNULL_BEGIN

// MARK: - Event Types

/// Event type enumeration
typedef NS_ENUM(NSInteger, ABBioEventType) {
    ABBioEventTypeSample,           ///< New biosignal sample
    ABBioEventTypeDeviceDiscovered, ///< Device discovered during scan
    ABBioEventTypeDeviceConnected,  ///< Device connected
    ABBioEventTypeDeviceDisconnected, ///< Device disconnected
    ABBioEventTypeDeviceStateChanged, ///< Device connection/stream state changed
    ABBioEventTypeDeviceFailed,     ///< Device connection failed
    ABBioEventTypeStreamStarted,    ///< Streaming started
    ABBioEventTypeStreamStopped,    ///< Streaming stopped
    ABBioEventTypeStreamStalled,    ///< Streaming stalled (no data)
    ABBioEventTypeError             ///< Error occurred
};

// MARK: - ABBioEvent

/// Base event class
@interface ABBioEvent : NSObject

/// Event type
@property (nonatomic, assign, readonly) ABBioEventType eventType;

/// Event timestamp
@property (nonatomic, strong, readonly) NSDate *timestamp;

/// Device ID (if applicable)
@property (nonatomic, copy, readonly, nullable) NSString *deviceId;

- (instancetype)initWithEventType:(ABBioEventType)eventType
                        timestamp:(NSDate *)timestamp
                         deviceId:(nullable NSString *)deviceId;

@end

// MARK: - Specific Event Classes

/// Sample event (new biosignal data)
@interface ABBioSampleEvent : ABBioEvent

@property (nonatomic, strong, readonly) ABBioSample *sample;

- (instancetype)initWithSample:(ABBioSample *)sample;

@end

/// Device discovered event
@interface ABBioDeviceDiscoveredEvent : ABBioEvent

@property (nonatomic, strong, readonly) ABBioDevice *device;

- (instancetype)initWithDevice:(ABBioDevice *)device;

@end

/// Device state changed event
@interface ABBioDeviceStateChangedEvent : ABBioEvent

@property (nonatomic, strong, readonly) ABBioDevice *device;
@property (nonatomic, assign, readonly) ABBioConnectionState connectionState;
@property (nonatomic, assign, readonly) ABBioStreamState streamState;

- (instancetype)initWithDevice:(ABBioDevice *)device
               connectionState:(ABBioConnectionState)connectionState
                   streamState:(ABBioStreamState)streamState;

@end

/// Error event
@interface ABBioErrorEvent : ABBioEvent

@property (nonatomic, copy, readonly) NSString *errorMessage;
@property (nonatomic, strong, readonly, nullable) NSError *error;

- (instancetype)initWithDeviceId:(nullable NSString *)deviceId
                    errorMessage:(NSString *)errorMessage
                           error:(nullable NSError *)error;

@end

NS_ASSUME_NONNULL_END
