//
//  ABProfileRegistry.h
//  BioBLECore
//
//  Device profile registry and loader
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#if __has_include(<BioSDK/ABDeviceProfile.h>)
#import <BioSDK/ABDeviceProfile.h>
#else
#import "ABDeviceProfile.h"
#endif

NS_ASSUME_NONNULL_BEGIN

/**
 * Central registry for device profiles.
 *
 * Manages loading and matching device profiles for BLE peripherals.
 * Supports:
 * - Loading schema-based profiles from bundle resources
 * - Registering custom profiles programmatically
 * - Matching peripherals to profiles by advertisement data
 * - Profile lookup by name or service UUIDs
 */
@interface ABProfileRegistry : NSObject

/**
 * Shared singleton instance.
 */
@property (class, nonatomic, readonly) ABProfileRegistry *sharedRegistry;

/**
 * All registered profiles.
 */
@property (nonatomic, copy, readonly) NSArray<id<ABDeviceProfile>> *profiles;

/**
 * Register a device profile.
 *
 * @param profile The profile to register
 */
- (void)registerProfile:(id<ABDeviceProfile>)profile;

/**
 * Unregister a device profile by name.
 *
 * @param name The profile name to unregister
 */
- (void)unregisterProfileWithName:(NSString *)name;

/**
 * Find the best matching profile for a peripheral.
 *
 * Matches based on:
 * 1. Service UUIDs in advertisement data
 * 2. Device name patterns
 * 3. Manufacturer data (if available)
 *
 * @param peripheral The peripheral to match
 * @param advertisementData The advertisement data dictionary
 * @return The matching profile, or nil if no match found
 */
- (nullable id<ABDeviceProfile>)profileForPeripheral:(CBPeripheral *)peripheral
                                    advertisementData:(NSDictionary<NSString *, id> *)advertisementData;

/**
 * Find a profile by name.
 *
 * @param name The profile name
 * @return The profile, or nil if not found
 */
- (nullable id<ABDeviceProfile>)profileWithName:(NSString *)name;

/**
 * Find profiles that support a specific service UUID.
 *
 * @param serviceUUID The service UUID to match
 * @return Array of matching profiles
 */
- (NSArray<id<ABDeviceProfile>> *)profilesWithServiceUUID:(CBUUID *)serviceUUID;

/**
 * Load built-in profiles from bundle resources.
 *
 * Searches for JSON schema files in the bundle's "Schemas" directory
 * and creates ABSchemaBasedProfile instances for each.
 *
 * @param bundle The bundle to search, or nil for main bundle
 */
- (void)loadBuiltInProfilesFromBundle:(nullable NSBundle *)bundle;

/**
 * Clear all registered profiles.
 */
- (void)clearAllProfiles;

@end

NS_ASSUME_NONNULL_END
